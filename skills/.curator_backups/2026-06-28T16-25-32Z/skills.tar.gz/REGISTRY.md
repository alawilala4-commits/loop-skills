# Hermes Skill Registry

## Core Pipeline Skills

| Skill | One-Line | Pipeline Position |
|-------|----------|-------------------|
| multi-agent-orchestrator | Task routing + workflow orchestration | ROOT SUPERVISOR |
| scout | Discovery awal | Intel → Stage 1 |
| search-engineering | Pencarian terarah | Intel → Stage 2 |
| research-verifier | Validasi bukti | Intel → Stage 3 |
| judge | Keputusan routing | Intel → Stage 4 |
| builder-drafter | Penyusunan output | Produksi → Stage 1 |
| quality-linter | Quality gate | Produksi → Stage 2 |
| handoff-committer | Final delivery | Produksi → Stage 3 |

## Specialist Skills

| Skill | One-Line | Domain |
|-------|----------|--------|
| test-driven-development | Code with tests | Code |
| systematic-debugging | Root-cause analysis | Debug |
| github-pr-workflow | PR/release flow | Release |
| claude-code | General agent execution | Agent |
| codex | Coding agent execution | Agent |

## Pipeline Flow

```
INTEL PIPELINE:
  scout → search-engineering → research-verifier → judge

PRODUKSI PIPELINE:
  builder-drafter → quality-linter → handoff-committer

CODING PIPELINE:
  test-driven-development → systematic-debugging → github-pr-workflow

AGENT EXECUTION:
  claude-code | codex (via multi-agent-orchestrator)
```

## Hierarchy

```
multi-agent-orchestrator (ROOT)
├── INTEL: scout → search → verify → judge
├── PRODUKSI: draft → lint → handoff
└── SPESIALIS: TDD, debugging, PR, claude-code, codex
```

---
Last updated: 2026-06-28
