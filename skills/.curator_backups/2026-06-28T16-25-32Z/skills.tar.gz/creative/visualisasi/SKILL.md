---
name: visualisasi
description: "Semua kebutuhan visualisasi: Wolfram Alpha query, architecture diagram, flowchart, concept map, data viz, infographic, sketch, generative art. Satu skill untuk semua."
version: 1.0.0
author: OWL Agent
license: MIT
dependencies: []
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [visualization, diagram, chart, graph, architecture, flowchart, infographic, wolfram, data-viz, sketch, generative-art]
    related_skills: [architecture-diagram, excalidraw, baoyu-infographic, p5js, manim-video, sketch]
---

# Visualisasi — Semua Visualisasi dalam Satu Skill

Satu skill untuk semua kebutuhan visualisasi. Pilih mode sesuai kebutuhan:

**User preference (Indonesia):** User komunikasi Bahasa Indonesia, suka langsung action (explain minimal).

| Mode | Input | Output | Use Case |
|------|-------|--------|----------|
| **wolfram** | Pertanyaan matematika/sains/data | Grafik/interaktif HTML dari Wolfram Alpha | Hitung, analisis data, plot fungsi |
| **architecture** | Deskripsi sistem/infra | Dark-themed SVG architecture diagram | Sistem, cloud, microservices |
| **flowchart** | Deskripsi proses/alur | Excalidraw .excalidraw file | Alur kerja, sequence, proses |
| **concept-map** | Konsep + relasi | SVG/HTML mind map | Peta konsep, hubungan ide |
| **data-viz** | Dataset (angka/CSV) | Interaktif HTML chart | Grafik batang, garis, pie, scatter |
| **infographic** | Konten/teks | HTML/PNG infographic | Ringkasan visual, presentasi |
| **sketch** | Deskripsi UI/screen | 2-3 HTML mockup variants | Eksplorasi UI, wireframe |
| **generative** | Konsep visual | p5.js HTML sketch | Seni generatif, animasi |
| **character** | Deskripsi karakter | SVG → PNG via cairosvg | Karakter game, mascot, portrait |

---

## Quick Test (Setelah membuat visualisasi)

Setelah generate file HTML, cara test:

```bash
# Linux/Termux
xdg-open ~/projects/visualisasi-test/contoh.html

# macOS
open ~/projects/visualisasi-test/contoh.html
```

Kalau terminal command blocked by approval (User denied), fallback:
- File tetap valid, user buka manual dari file manager
- Atau gunakan `skill_view` untuk review skill dan generate ulang

**Note:** Kalau user minta "testing langsung" atau "cek langsung", JANGAN explain panjang — langsung buat file + informasikan path-nya.

---

## Mode 1: Wolfram Alpha Query

**Gunakan saat:** User minta perhitungan, plot fungsi, data analysis, konversi, atau pertanyaan sains/matematika.

### Workflow
1. Terima pertanyaan (bahasa apapun, translate ke English untuk query)
2. Fetch via web atau generate Wolfram Alpha URL
3. Hasilkan HTML interaktif dengan embedded Wolfram Alpha result

### URL Format
```
https://www.wolframalpha.com/input?i={encoded_query}
```

### Contoh Query
- `integrate x^2 sin(x) dx`
- `plot sin(x) from 0 to 2pi`
- `GDP of Indonesia 2024`
- `distance from Jakarta to Surabaya`
- `weather in Bandung`
- `population of Southeast Asia`
- `derivative of e^x * cos(x)`

### Iframe Embedding Pattern
Gunakan iframe untuk menampilkan Wolfram Alpha result langsung (tidak perlu screenshot):
```html
<iframe src="https://www.wolframalpha.com/input?i={encoded_query}"
        frameborder="0" width="100%" height="600px"></iframe>
```
Output: standalone HTML yang bisa dibuka di browser atau dikirim via Telegram (view-only, interactive di link).

### Output
Generate standalone HTML file yang:
- Menampilkan Wolfram Alpha result via iframe atau screenshot
- Menampilkan query asli dan hasil terjemahan
- Styling dark-themed konsisten dengan architecture diagram
- Include link ke Wolfram Alpha untuk interaksi lebih

### Template
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Wolfram Alpha: {query}</title>
  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'JetBrains Mono', monospace; background: #020617; color: white; min-height: 100vh; padding: 2rem; }
    .container { max-width: 1000px; margin: 0 auto; }
    .header { margin-bottom: 2rem; }
    h1 { font-size: 1.25rem; font-weight: 700; margin-bottom: 0.5rem; }
    .query { color: #22d3ee; font-size: 0.9rem; word-break: break-all; }
    .result-box { background: rgba(15, 23, 42, 0.5); border: 1px solid #1e293b; border-radius: 1rem; padding: 1.5rem; margin-top: 1rem; }
    .link { color: #22d3ee; font-size: 0.8rem; margin-top: 1rem; display: inline-block; }
    iframe { width: 100%; height: 600px; border: none; border-radius: 0.5rem; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Wolfram Alpha Result</h1>
      <p class="query">{query}</p>
    </div>
    <div class="result-box">
      <iframe src="https://www.wolframalpha.com/input?i={encoded_query}" frameborder="0"></iframe>
    </div>
    <a class="link" href="https://www.wolframalpha.com/input?i={encoded_query}" target="_blank">Open in Wolfram Alpha →</a>
  </div>
</body>
</html>
```

---

## Mode 2: Architecture Diagram

**Gunakan saat:** User minta diagram arsitektur sistem, cloud infrastructure, microservices, database map.

Lihat skill `architecture-diagram` untuk full reference (template, color palette, component types).

### Quick Workflow
1. Identifikasi komponen (frontend, backend, database, cloud, security, message bus)
2. Tentukan koneksi antar komponen
3. Generate HTML dengan SVG inline
4. Save sebagai `.html` file

### Color Palette (WAJIB)
| Component | Fill | Stroke |
|-----------|------|------|
| Frontend | `rgba(8, 51, 68, 0.4)` | `#22d3ee` |
| Backend | `rgba(6, 78, 59, 0.4)` | `#34d399` |
| Database | `rgba(76, 29, 149, 0.4)` | `#a78bfa` |
| Cloud/AWS | `rgba(120, 53, 15, 0.3)` | `#fbbf24` |
| Security | `rgba(136, 19, 55, 0.4)` | `#fb7185` |
| Message Bus | `rgba(251, 146, 60, 0.3)` | `#fb923c` |
| External | `rgba(30, 41, 59, 0.5)` | `#94a3b8` |

---

## Mode 3: Flowchart

**Gunakan saat:** User minta flowchart, sequence diagram, process flow, decision tree.

Lihat skill `excalidraw` untuk format element JSON.

### Quick Workflow
1. Identifikasi steps, decisions, dan flow
2. Generate Excalidraw JSON elements
3. Save sebagai `.excalidraw` file
4. User buka di excalidraw.com

### Alternative: HTML Flowchart
Untuk simplicity, generate HTML+SVG flowchart langsung:
```html
<!-- Gunakan SVG rectangles + arrows + text -->
<!-- Styling sama dengan architecture diagram (dark theme) -->
```

---

## Mode 4: Concept Map / Mind Map

**Gunakan saat:** User minta peta konsep, mind map, hubungan antar ide.

### Output
SVG-based mind map dengan:
- Central node (konsep utama) — larger, bold
- Branch nodes (sub-konsep) — connected with lines
- Color-coded by depth/category
- Dark theme, JetBrains Mono font

### Layout Algorithm
1. Center = main concept
2. Level 1 = circular distribution (radius 200px)
3. Level 2 = further out (radius 350px)
4. Lines: curved bezier between nodes
5. Colors: rotate hue per branch

---

## Mode 5: Data Visualization

**Gunakan saat:** User minta grafik dari data (bar chart, line chart, pie chart, scatter plot).

### Output
Standalone HTML file dengan:
- Chart rendering via inline SVG atau lightweight JS (Chart.js CDN)
- Dark theme konsisten
- Interactive tooltips
- Legend

### Supported Chart Types
- **Bar chart** — perbandingan kategori
- **Line chart** — tren waktu
- **Pie/Donut** — proporsi
- **Scatter plot** — korelasi
- **Area chart** — kumulatif
- **Radar/Spider** — multi-variabel

### Template Structure
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Data Visualization</title>
  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body { font-family: 'JetBrains Mono', monospace; background: #020617; color: white; padding: 2rem; }
    .chart-container { background: rgba(15, 23, 42, 0.5); border: 1px solid #1e293b; border-radius: 1rem; padding: 1.5rem; max-width: 900px; margin: 0 auto; }
  </style>
</head>
<body>
  <div class="chart-container">
    <canvas id="chart"></canvas>
  </div>
  <script>
    // Chart.js config with dark theme
  </script>
</body>
</html>
```

---

## Mode 6: Infographic

**Gunakan saat:** User minta ringkasan visual, info besar, educational graphic.

Lihat skill `baoyu-infographic` untuk 21 layouts × 21 styles.

### Quick Workflow
1. Analisis konten (data, pesan, audience)
2. Pilih layout yang cocok
3. Generate HTML infographic
4. Export ke PNG jika perlu

---

## Mode 7: UI Sketch / Mockup

**Gunakan saat:** User minta wireframe, UI mockup, screen design exploration.

Lihat skill `sketch` untuk workflow lengkap (2-3 variants, comparison).

### Quick Workflow
1. Tentukan feel/references/core action
2. Generate 2-3 HTML variants
3. Save ke `sketches/{topic}-{stance}/index.html`

---

## Mode 8: Generative Art

**Gunakan saat:** User minta seni generatif, visualisasi animasi, creative coding.

Lihat skill `p5js` untuk full pipeline.

### Quick Workflow
1. Tentukan mood, color world, motion vocabulary
2. Pilih: animated atau static
3. Generate single HTML file dengan p5.js
4. Export ke PNG/GIF/MP4 sesuai kebutuhan

---

## Mode 9: Character / Illustration (SVG + CairoSVG)

**Gunakan saat:** User minta generate gambar karakter, mascot, portrait, atau figur spesifik.

**KENAPA SVG, bukan Pillow?** Pillow hasilnya jelek + serem untuk karakter (cuma bentuk dasar: lingkaran, elips). SVG via `cairosvg` menghasilkan gambar berkualitas tinggi di Termux — gradients, gradients, filter, transform semua didukung.

### Pipeline

```
Python SVG string → cairosvg.svg2png() → PNG file → kirim via MEDIA:
```

### Dependencies

```bash
pip3 install cairosvg
# (otomatis install cairocffi, cssselect2, tinycss2, defusedxml)
```

### RNG Pattern (WAJAI BUG INI!)

```python
# SALAH — generator object bukan callable
def rng(s):
    while True:
        s = (s * 16807) % 2147483647
        yield s / 2147483647
r = rng(seed)
r()  # TypeError: 'generator' object is not callable

# BENAR — callable class
class RNG:
    def __init__(self, s):
        self.s = s
    def __call__(self):
        self.s = (self * 16807) % 2147483647
        return self.s / 2147483647
r = RNG(seed)
r()  # OK!
```

### SVG Structure untuk Karakter

Gunakan pattern ini untuk karakter yang bagus:

1. **`<defs>` section** — gradients, filters (shadow, blur), define once
2. **Background** — rect with gradient (sky/ground split)
3. **Environment elements** — clouds, trees, flowers, grass (back to front)
4. **Character** — shadow ellipse → feet → body → arms → head → face details → accessories
5. **Decorations** — sparkles, butterfly, particles
6. **Render** — `cairosvg.svg2png(bytestring=svg.encode(), write_to=path, output_width=512, output_height=512)`

### Wajib di SVG Character

- **Radial gradient untuk kulit/head** — biar ada volume
- **Filter drop shadow** — biar karakter nggak "mengambang"
- **Cheek blush** (radial pink dengan opacity fade) — biar cute
- **Eye highlights** (putih kecil) — biar mata "hidup"
- **Sparkle Unicode characters** (`✦`, `*`) — dekorasi universal yang render rapi
- **Wing/ellipse pakai min/max** — hindari `x1 > x0` error saat direction negatif

### Pitfall Khusus Character

1. **Jangan buat karakter horror tanpa sengaja** — dark palette + mata tajam + tanpa pipi = creepy. Pakai palette bright/warm + blush + mata bulat = cute
2. **Ellipse coordinates HARUS x0 <= x1** — saat pakai left-side + negative width, selalu `min()` / `max()` atau `abs()`
3. **cairosvg butuh Ruang disk** — pastikan ada space untuk PNG output (~40-80KB per gambar)
4. **Telegram PNG max 10MB** — karakter SVG→PNG biasanya ~50-200KB, aman
5. **Font availability di Cairo** — beberapa font nggak ada di Termux. Pakai `font-family="sans-serif"` atau generic

### Template Lengkap

Lihat `templates/character-template.svg` untuk template copy-paste yang sudah teruji menghasilkan karakter cute nature. 

---

## Decision Tree

Ketika user minta visualisasi, tanyakan:

1. **"Apa yang mau divisualisasikan?"**
   - Data/angka → Mode 5 (Data Viz)
   - Sistem/arsitektur → Mode 2 (Architecture)
   - Proses/alur → Mode 3 (Flowchart)
   - Konsep/hubungan → Mode 4 (Concept Map)
   - Perhitungan/sains → Mode 1 (Wolfram)
   - Ringkasan info → Mode 6 (Infographic)
   - UI/screen → Mode 7 (Sketch)
   - Seni/animasi → Mode 8 (Generative)

2. **"Outputnya apa?"**
   - HTML file (interactive, buka di browser)
   - PNG image
   - Excalidraw file (untuk edit lebih)
   - MP4 video (untuk animasi)

3. **"Berapa banyak variasi?"**
   - 1 final → langsung generate
   - 2-3 variants → sketch mode

---

## Pitfalls

1. **Jangan campur warna tanpa sistem** — selalu pakai palette yang didefinisikan
2. **Jangan lupa font** — JetBrains Mono untuk tech, sesekali Inter untuk UI
3. **Jangan over-generate SVG** — kompleksitas tinggi = render lambat
4. **Selalu save sebagai file** — jangan output inline, user harus bisa buka
5. **Jangan lupa link/reference** — untuk Wolfram, Excalidraw, selalu kasih link
6. **Data integrity** — jangan ubah angka/data asli, tampilkan apa adanya
7. **Mobile responsive** — diagram harus readable di layar kecil
8. **Accessibility** — selalu ada text label, jangan hanya warna
9. **PILLOW TIDAK COCOK UNTUK GAMBAR KARAKTER** — hasilnya jelek/serem. Gunakan SVG + `cairosvg` untuk karakter/figur (lihat Mode 9)
10. **RNG harus callable, bukan generator** — `def rng(s): yield...` produces generator object that errors when called as `r()`. Pakai class pattern: `class RNG: def __call__(self): self.s = (self.s*16807)%2147483647; return self.s/2147483647`
11. **Termux punya batasan tool** — nggak ada Chromium/Playwright untuk render HTML→PNG. `cairosvg` (pip install cairosvg) adalah jalur terbaik SVG→PNG di Termux.
12. **Telegram cuma terima file gambar** — HTML/JSON/excalidraw TIDAK bisa dikirim langsung ke Telegram. Harus dikonversi ke PNG/JPG dulu.

---

## References & Templates

| File | Purpose |
|------|---------|
| `references/wolfram-alpha.md` | Wolfram Alpha query patterns, embedding options, common queries |
| `references/termux-image-generation.md` | Termux constraints, SVG→cairosvg pipeline, RNG pattern, pitfalls |
| `templates/data-viz.html` | Starter HTML for Chart.js data visualization (copy & modify) |
| `templates/character-template.svg` | Copy-paste SVG template for cute character generation (tested, working) |
| `scripts/visualize.py` | CLI generator: `python3 visualize.py wolfram|flowchart|architecture` |

---

## Integration dengan Skill Lain

| Skill | Kapan pakai |
|-------|------------|
| `architecture-diagram` | Detail arsitektur sistem, full template |
| `excalidraw` | Flowchart yang mau diedit user |
| `baoyu-infographic` | Infographic dengan 21 layout |
| `p5js` | Generative art, interactive viz |
| `manim-video` | Animasi edukasi, math explanation |
| `sketch` | UI mockup variants |
